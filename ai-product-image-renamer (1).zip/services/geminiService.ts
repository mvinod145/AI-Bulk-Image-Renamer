// This function converts the file to a base64 string for JSON transport
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        if (typeof reader.result === 'string') {
            // result is "data:image/jpeg;base64,LzlqLzRBQ...". We only want the part after the comma.
            resolve(reader.result.split(',')[1]);
        } else {
            reject(new Error("Failed to read file as data URL."));
        }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};

export const renameImage = async (file: File, itemCode: string): Promise<string> => {
  // In a real deployment, you would point this to your live server URL
  // For local testing, it would be 'http://localhost:3001/api/rename'
  const API_ENDPOINT = '/api/rename'; 
  
  const imageBase64 = await fileToBase64(file);

  try {
    const response = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        itemCode: itemCode,
        imageBase64: imageBase64,
        mimeType: file.type,
      }),
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Server responded with status: ${response.status}`);
    }

    const data = await response.json();
    const newName = data.newName;
    
    if (!newName) {
        throw new Error("The server returned an empty response.");
    }

    // Basic validation to ensure the output looks like a filename
    if (!/^\w+_\d\.jpg$/.test(newName.trim())) {
        console.warn(`AI returned a non-standard filename: ${newName}`);
    }
    
    return newName;
  } catch (error) {
    console.error("Error calling backend proxy:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    throw new Error(`Failed to process image: ${errorMessage}`);
  }
};
