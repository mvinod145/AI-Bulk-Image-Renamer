import React, { useState } from 'react';
import { ProcessedImage } from '../types';
import Loader from './Loader';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';
import { ExclamationTriangleIcon } from './icons/ExclamationTriangleIcon';

interface ResultCardProps {
  image: ProcessedImage;
}

const ResultCard: React.FC<ResultCardProps> = ({ image }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (image.newName) {
      navigator.clipboard.writeText(image.newName);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl">
      <div className="relative w-full h-48 bg-slate-200">
        <img src={image.previewUrl} alt={image.originalName} className="w-full h-full object-cover" />
        {image.status === 'processing' && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <Loader />
          </div>
        )}
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <div className="mb-3">
          <p className="text-xs text-slate-500">Original Name</p>
          <p className="text-sm font-medium text-slate-700 truncate" title={image.originalName}>
            {image.originalName}
          </p>
        </div>
        
        <div className="flex-grow">
          <p className="text-xs text-slate-500">New Name</p>
          {image.status === 'pending' && (
             <div className="mt-1 flex items-center">
                <p className="text-sm text-slate-500 italic">Ready to process...</p>
             </div>
          )}
          {image.status === 'completed' && (
            <div className="flex items-center justify-between mt-1">
              <p className="text-sm font-semibold text-green-700 bg-green-100 px-2 py-1 rounded-md flex-grow truncate mr-2" title={image.newName}>
                {image.newName}
              </p>
              <button
                onClick={handleCopy}
                className="p-2 rounded-full text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
                title="Copy name"
              >
                {copied ? (
                   <CheckIcon className="w-5 h-5 text-green-600" />
                ) : (
                   <ClipboardIcon className="w-5 h-5" />
                )}
              </button>
            </div>
          )}
          {image.status === 'error' && (
             <div className="flex items-center mt-1 p-2 bg-red-100 rounded-md">
                <ExclamationTriangleIcon className="w-5 h-5 text-red-600 mr-2 flex-shrink-0"/>
                <p className="text-xs text-red-700 font-medium" title={image.errorMessage}>
                    {image.errorMessage}
                </p>
             </div>
          )}
           {image.status === 'processing' && (
             <div className="mt-1 h-8 w-3/4 bg-slate-200 rounded animate-pulse"></div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResultCard;