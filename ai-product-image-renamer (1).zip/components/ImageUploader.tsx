import React, { useState, useCallback, useRef } from 'react';
import { PhotoIcon } from './icons/PhotoIcon';

interface ImageUploaderProps {
  onFilesSelected: (files: File[]) => void;
  disabled?: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onFilesSelected, disabled = false }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if(disabled) return;
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if(disabled) return;
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if(disabled) return;
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const imageFiles = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
      if(imageFiles.length > 0) {
        onFilesSelected(imageFiles);
      }
      e.dataTransfer.clearData();
    }
  }, [onFilesSelected, disabled]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
       const imageFiles = Array.from(e.target.files).filter(file => file.type.startsWith('image/'));
       if(imageFiles.length > 0) {
        onFilesSelected(imageFiles);
       }
    }
  };
  
  const handleClick = () => {
    if (disabled) return;
    fileInputRef.current?.click();
  };

  const borderColor = isDragging && !disabled ? 'border-indigo-600' : 'border-slate-400';
  const bgColor = isDragging && !disabled ? 'bg-indigo-50' : 'bg-white';
  const cursorClass = disabled ? 'cursor-not-allowed' : 'cursor-pointer';
  const opacityClass = disabled ? 'opacity-60' : '';

  return (
    <div
      className={`group relative flex justify-center rounded-lg border-2 border-dashed ${borderColor} ${bgColor} ${cursorClass} ${opacityClass} px-6 py-10 transition-colors duration-200 ease-in-out`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleClick}
      aria-disabled={disabled}
    >
      <div className="text-center">
        <PhotoIcon className="mx-auto h-12 w-12 text-slate-400 group-hover:text-indigo-600 transition-colors"/>
        <div className="mt-4 flex text-sm leading-6 text-slate-600">
          <span className="font-semibold text-indigo-600">Upload files</span>
          <p className="pl-1">or drag and drop</p>
        </div>
        <p className="text-xs leading-5 text-slate-500">PNG, JPG, GIF, etc.</p>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
        disabled={disabled}
      />
    </div>
  );
};

export default ImageUploader;